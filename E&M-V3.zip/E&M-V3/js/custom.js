var footerHeight = $('footer').height();
var sliderplus = 0;

function slider(){ 
   setTimeout(() => {
      var sliderwidth = $('.rangeSlider .deactive-line').width();
      var sliderliwidth = sliderwidth / 7;
      $('.rangeSlider li').css('width', sliderliwidth+'px');    
   }, 200);  
}
function sliderTwo(){
   setTimeout(() => {
      var sliderwidthTwo = $('.deactive-line').width();   
      var sliderliwidthTwo = sliderwidthTwo / 7;
      $('.rangeSlider-two li').css('width', sliderliwidthTwo+'px');
   }, 200);   
}

$('#pills-time-tab').on('click', function(){
   slider();
   sliderTwo();
})

// tooltip on
$('[data-toggle="popover"]').popover({html:true});;

$('.barslider').on('click', function(){
   sliderplus++
   var slideraddfloating = sliderplus * 20;   
   $(this).css('left',slideraddfloating+'%');
   $('.active-line').css('width', slideraddfloating+'%');
   $('.cptTwo').css({'display' : 'block', 'visibility' : 'visible'});

   if (slideraddfloating == 100) {
      $('.barslider').css('pointer-events', 'none');
   } else {
      
   }

})
$('.barslider-two').on('click', function(){
   sliderplus++
   var slideraddfloating = sliderplus * 20;   
   $(this).css('left',slideraddfloating+'%');
   $('.active-line-two').css('width', slideraddfloating+'%');
   $('.cptTwo').css({'display' : 'block', 'visibility' : 'visible'});
})

$('.medical-tab-section .nav-item a').on('click', function(){
   var openbreadcum = $(this).attr('id');
   if(openbreadcum == 'pills-decision-tab'){      
      $('.bread-bg').show();
      $('.cpt-code-info').css('visibility','visible'); 
      $('.cpt-time-info').css('visibility','hidden');    
   } else if(openbreadcum == 'pills-time-tab'){
      $('.cpt-code-info').css('visibility','hidden');       
      $('.cpt-time-info').css('visibility','visible');
      $('.bread-bg').hide();
   } else {
      $('.cpt-code-info').css('visibility','hidden');        
      $('.cpt-time-info').css('visibility','hidden');
      $('.bread-bg').hide();
   }
})

$('.checkbox-wrap input').on('click', function(){   
   $(this).parent().parent().toggleClass('checkbox-bg');
   $(this).toggleClass('ischeck');
   var headingoflistbox = $(this).parent().parent().parent().attr('data-headingname');
   var showdatabox = $(this).parent().parent().parent().parent().parent();
   var showdataboxmain = $(this).parent().parent().parent();
   var getpageid = $(this).parent().parent().parent().parent().parent().attr('id');
   var getcheckboxactive = $('div[data-headingname="' + headingoflistbox +'"] input.ischeck').length;
   
   // alert(headingoflistbox);

   $(showdatabox).removeClass('minimal-class');
   $(showdatabox).removeClass('low-class');
   $(showdatabox).removeClass('moderate-class');
   $(showdatabox).removeClass('high-class');
   $(showdatabox).removeClass('category1-class');
   $(showdatabox).removeClass('category2-class');
   $(showdatabox).removeClass('category3-class');

   if (headingoflistbox == 'Minimal') {
      $(showdatabox).addClass('minimal-class');
      $('.minimal-class h4 span').show();
      $('.minimal-class h4 span').text('Minimal');

      if (getcheckboxactive >= 1) {         
         //$('div[data-headingname="Low"] .custom-checkbox label').addClass('pointerNone');
         //$('div[data-headingname="Moderate"] .custom-checkbox label').addClass('pointerNone');
         //$('div[data-headingname="High"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(1) a b').text(headingoflistbox);
      } else {
         //$('div[data-headingname="Low"] .custom-checkbox label').removeClass('pointerNone');
         //$('div[data-headingname="Moderate"] .custom-checkbox label').removeClass('pointerNone');
         //$('div[data-headingname="High"] .custom-checkbox label').removeClass('pointerNone');
         $('.minimal-class h4 span').hide();
         $('.bredcumlist li:nth-child(1) a b').text('Select');
      }
      

   } else if (headingoflistbox == 'Low'){
      $(showdatabox).addClass('low-class');
      $('.low-class h4 span').show();
      $('.low-class h4 span').text('Low');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Minimal"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Moderate"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="High"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(1) a b').text(headingoflistbox);
      } else {
         // $('div[data-headingname="Minimal"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Moderate"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="High"] .custom-checkbox label').removeClass('pointerNone');
         $('.low-class h4 span').hide();
         $('.bredcumlist li:nth-child(1) a b').text('Select');
      }

   } else if (headingoflistbox == 'Moderate'){
      $(showdatabox).addClass('moderate-class');
      $('.moderate-class h4 span').show();
      $('.moderate-class h4 span').text('Moderate');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Minimal"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Low"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="High"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(1) a b').text(headingoflistbox);
      } else {
         // $('div[data-headingname="Minimal"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Low"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="High"] .custom-checkbox label').removeClass('pointerNone');
         $('.moderate-class h4 span').hide();
         $('.bredcumlist li:nth-child(1) a b').text('Select');
      }

   } else if (headingoflistbox == 'High'){
      $(showdatabox).addClass('high-class');
      $('.high-class h4 span').show();
      $('.high-class h4 span').text('High');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Minimal"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Low"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Moderate"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(1) a b').text(headingoflistbox);         
      } else {
         // $('div[data-headingname="Minimal"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Low"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Moderate"] .custom-checkbox label').removeClass('pointerNone');
         $('.high-class h4 span').hide();
         $('.bredcumlist li:nth-child(1) a b').text('Select');
      }

   } else if (headingoflistbox == 'Category1'){      
      $(showdatabox).addClass('category1-class');
      $('.category1-class h4 span').show();
      $('.category1-class h4 span').text('Low');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Category2"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Category3"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(2) a b').text('Low');

      }  else {
         // $('div[data-headingname="Category2"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Category3"] .custom-checkbox label').removeClass('pointerNone');
         $('.category1-class h4 span').hide();
         $('.bredcumlist li:nth-child(2) a b').text('Select');
      }

      if (getcheckboxactive == 1) {
         $(showdataboxmain).addClass('checkbox-bg');                      
      } else {
         $(showdataboxmain).removeClass('checkbox-bg');              
      }

   } else if (headingoflistbox == 'Category2'){
      $(showdatabox).addClass('category2-class');
      $('.category2-class h4 span').show();
      $('.category2-class h4 span').text('Moderate');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Category1"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Category3"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(2) a b').text('Moderate');
      } else {
         // $('div[data-headingname="Category1"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Category3"] .custom-checkbox label').removeClass('pointerNone');
         $('.category2-class h4 span').hide();
         $('.bredcumlist li:nth-child(2) a b').text('Select');
      }

      if (getcheckboxactive == 1) {
         $(showdataboxmain).addClass('checkbox-bg');                      
      } else {
         $(showdataboxmain).removeClass('checkbox-bg');              
      }

   } else if (headingoflistbox == 'Category3'){
      $(showdatabox).addClass('category3-class');
      $('.category3-class h4 span').show();
      $('.category3-class h4 span').text('High');

      if (getcheckboxactive >= 1) {         
         // $('div[data-headingname="Category1"] .custom-checkbox label').addClass('pointerNone');
         // $('div[data-headingname="Category2"] .custom-checkbox label').addClass('pointerNone');
         $('.bredcumlist li:nth-child(2) a b').text('High');
      } else {
         // $('div[data-headingname="Category1"] .custom-checkbox label').removeClass('pointerNone');
         // $('div[data-headingname="Category2"] .custom-checkbox label').removeClass('pointerNone');
         $('.category3-class h4 span').hide();
         $('.bredcumlist li:nth-child(2) a b').text('Select');
      }

      if (getcheckboxactive == 1) {
         $(showdataboxmain).addClass('checkbox-bg');                      
      } else {
         $(showdataboxmain).removeClass('checkbox-bg');              
      }

   } else if (headingoflistbox == 'Minimal1'){
      $('#page3 h4 span').show();
      $('#page3 h4 span').text('Minimal');
      if (getcheckboxactive >= 1) {         
         $('.bredcumlist li:nth-child(3) a b').text('Minimal');
      } else {
         $('#page3 h4 span').hide();
         $('.bredcumlist li:nth-child(3) a b').text('Select');
      }
   } else if (headingoflistbox == 'Low1'){
      $('#page3 h4 span').show();
      $('#page3 h4 span').text('Low');
      if (getcheckboxactive >= 1) {         
         $('.bredcumlist li:nth-child(3) a b').text('Low');
      } else {
         $('#page3 h4 span').hide();
         $('.bredcumlist li:nth-child(3) a b').text('Select');
      }
   } else if (headingoflistbox == 'Moderate1'){
      $('#page3 h4 span').show();
      $('#page3 h4 span').text('Moderate');
      if (getcheckboxactive >= 1) {         
         $('.bredcumlist li:nth-child(3) a b').text('Moderate');
      } else {
         $('#page3 h4 span').hide();
         $('.bredcumlist li:nth-child(3) a b').text('Select');
      }
   } else if (headingoflistbox == 'High1'){
      $('#page3 h4 span').show();
      $('#page3 h4 span').text('High');
      if (getcheckboxactive >= 1) {         
         $('.bredcumlist li:nth-child(3) a b').text('High');
      } else {
         $('#page3 h4 span').hide();
         $('.bredcumlist li:nth-child(3) a b').text('Select');
      }
   }


   breadcum();  
})

function breadcum(){
   var breadcumtext = $('.bredcumlist li:nth-child(1) a b').text();
   var breadcumtext2 = $('.bredcumlist li:nth-child(2) a b').text();
   if (breadcumtext == 'Select' || breadcumtext2 == 'Select') {
      $('.cpt-code-info').hide();
   } else {
      $('.cpt-code-info').show();
   }
}

$('#encounter li').on('click', function(){
   var encounText = $(this).text();
   $('.btn-group button.encounterName').text(encounText + " ");

   if (encounText == 'New') {
      $('.rangeSlider').hide();
      $('.barSecond').show();
   } else {
      $('.rangeSlider').show();
      $('.barSecond').hide();
   }

})

$('.dasktop').on('click', function(){ 
   $('.summary-section').toggleClass('rightPannelAnimation');
   $('.layerMask').show();
   $('.medical-box').removeClass('elementHide');
   // $('.summary-box').addClass('fadeInRight animated');
   $('.time-box').addClass('elementHide');
   //$('.disclaimer-right').addClass('elementHide');
   $('body').css('overflow', 'hidden');
})
$('.dasktop-time').on('click', function(){ 
   $('.summary-section').toggleClass('rightPannelAnimation');
   $('.layerMask').show();
   $('.time-box').removeClass('elementHide');
   // $('.summary-box').addClass('fadeInRight animated');
   //$('.disclaimer-right').removeClass('elementHide');
   $('.medical-box').addClass('elementHide');
   $('body').css('overflow', 'hidden');
})

$('.closeArea i').on('click', function(){
   $('.summary-section').toggleClass('rightPannelAnimation');
   // $('.summary-box').toggleClass('fadeInRight animated');
   $('.layerMask').hide();
   $('body').css('overflow', 'auto');
})
$('.layerMask').on('click', function(){
   $('.summary-section').toggleClass('rightPannelAnimation');
   // $('.summary-box').toggleClass('fadeInRight animated');
   $(this).hide();
   $('body').css('overflow', 'auto');
})

function readMore() {
   var dots = document.getElementById("dots");
   var moreText = document.getElementById("more");
   var btnText = document.getElementById("myBtn");
 
   if (dots.style.display === "none") {
     dots.style.display = "inline";
     btnText.innerHTML = "more..."; 
     moreText.style.display = "none";
   } else {
     dots.style.display = "none";
     btnText.innerHTML = "less..."; 
     moreText.style.display = "inline";
   }
 }

$('.refresh-icon').click(function() {
   location.reload();
});

$('.summary-wrap li a').on('click', function(){
   var textnum = $(this).text();   
   $('.subMenu-wrap .sub-left span b').text(textnum);
})

$('.newUser a').on('click', function(){
   $('.forgotpass, .newUser, .byClick, .login').hide();
   $('.signup-info, .createuser, .existingUser, .signup-field').show();
});

$('.existingUser a').on('click', function(){
   $('.forgotpass, .newUser, .byClick, .login').show();
   $('.signup-info, .createuser, .existingUser, .signup-field').hide();
});

